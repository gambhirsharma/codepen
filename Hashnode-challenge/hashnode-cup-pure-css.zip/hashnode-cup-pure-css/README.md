# Hashnode Cup | Pure CSS |

A Pen created on CodePen.io. Original URL: [https://codepen.io/gambhirsharma/pen/XWePxVa](https://codepen.io/gambhirsharma/pen/XWePxVa).

